function [X_best,Best_fit,All_fit,nfes,res_det]= APGSK_IMODE_FL(max_nfes,L,H,func_num,D,fhd,C,Par,Run_No)

load Rand_Seeds Rand_Seeds
rng(D*func_num*Rand_Seeds(Run_No),'twister');

D=Par.n;
lu = [L * ones(1, D); H * ones(1, D)];
NP=Par.PopSize;
max_NP = NP;
min_NP = 12.0;
min_NP1=4;

filename = strcat(strcat('Fx_\F',num2str(func_num)),'_APGSK_IMODE_FL_',num2str(D),'_2022_long.txt');
fp = fopen(filename,'a+');

Pop = repmat(lu(1, :), NP, 1) + rand(NP, D) .* (repmat(lu(2, :) - lu(1, :), NP, 1));

Fit=feval(fhd,Pop',func_num,C);
nfes = NP;

filedata0=strcat(num2str(nfes),32, num2str(mean(Fit-Par.f_optimal)),32, num2str(min(Fit-Par.f_optimal)),'\n');

Fit=Fit';
[~,I_best]=min(Fit);
X_best=Pop(I_best,:);

res_det= min(repmat(min(Fit),Par.PopSize,1), Fit); %% used to record the convergence

PS2=NP/2;
PS1=NP-PS2;
PS2=NP-PS1;

max_NP1=PS1;
max_NP2=PS2;
%% ================== fill in for each  Algorithm ===================================
%% IMODE
EA_1= Pop(1:PS1,:);    EA_obj1= Fit(1:PS1);
Pre_EA_1 = EA_1;    Pre_EA_obj1 = EA_obj1;
EA_1_Cnt = zeros(size(EA_obj1));
%% APGSK
EA_2= Pop(PS1+1:size(Pop,1),:);    EA_obj2= Fit(PS1+1:size(Pop,1));
Pre_EA_2 = EA_2;    Pre_EA_obj2 = EA_obj2;
EA_2_Cnt = zeros(size(EA_obj2));
%% ===================== archive data ====================================
arch_rate=1.4;
archive.NP = arch_rate * PS1; % the maximum size of the archive
archive.pop = zeros(0, Par.n); % the solutions stored in te archive
archive.funvalues = zeros(0, 1); % the function value of the archived solutions



%% APGSK setting
%%POSSIBLE VALUES FOR KNOWLEDGE RATE K%%%%
EA_1old=EA_1;
hist_pos=1;
memory_size=15*Par.n;
archive_f= ones(1,memory_size).*0.5;
archive_Cr= ones(1,memory_size).*0.5;
archive_T = ones(1,memory_size).*0.1;
archive_freq = ones(1, memory_size).*0.5;
F = normrnd(0.5,0.15,1,NP);
cr= normrnd(0.5,0.15,1,NP);
probDE1=1./Par.n_opr .* ones(1,Par.n_opr);
[bestold, bes_l]=min(Fit);     bestx= Pop(bes_l,:);
Probs=[1 1];
it=0;
cy=0;
stop_con=0;
xxx=0;
p=0.1;%取前50%交换
times1 = 0;
times2 = 0;
tra = 0.3;


pools = [[70 85 37 42];[100 100 100 100];[70 85 35 40]]; % parameter pools

pre_best = intmax;

cur_id = 1;
while stop_con==0 % nfes<max_nfes
    
    it=it+1;
    cy=cy+1; % to control CS
    %  ================ determine the best phase ===========================
    if(cy==ceil(Par.CS+1))
        
        %%calc normalized qualit -- NQual
        qual(1) = min(EA_obj1);
        qual(2) = min(EA_obj2);
        norm_qual = qual./sum(qual);
        norm_qual=1-norm_qual; %% to satisfy the bigger is the better
        Probs=norm_qual;
        %%Update Prob_MODE and Prob_CMAES
        Probs = max(0.1, min(0.9,Probs./sum(Probs)));
        
%         pops(1) = max(EA_1_Cnt)-10;
%         pops(2) = max(EA_2_Cnt)-10;
        max1 = max(EA_1_Cnt);
        max2 = max(EA_2_Cnt);
        tmp_1 = min([max1 max2 80]);
        
        
        [~,indx]=max(Probs);
        if Probs(1)==Probs(2)
            indx=0;%% no sharing of information
%             pops = [70 85];
            pops = [pools(cur_id,1) pools(cur_id,2)];
        end
        if indx>0
            
            Probs=[0 0];
%             pops = [37 40];
            pops = [pools(cur_id,3) pools(cur_id,4)];
            Probs(indx)=1;
%             pops(indx)=70;
            if indx==1
                pops(indx) = pools(cur_id,1);
            else
                pops(indx) = pools(cur_id,2);
            end
        end
    elseif cy==2*ceil(Par.CS)
        %% share information
        if indx==1

%             %%交换，将IMODE中多次没有变化的个体使用AGPSK算法
            [~, ind11]=sort(EA_obj1,'descend');
            [~, ind21]=sort(EA_obj2,'descend');
            
            [~,ind12] = sort(EA_1_Cnt,'descend');
            [~,ind22] = sort(EA_2_Cnt,'descend');
            
%             total1 = round(numel(EA_obj1(:,1))*p);
%             total2 = round(numel(EA_obj2(:,1))*p);

            total1 = sum(EA_1_Cnt>pops(1));
            total2 = sum(EA_2_Cnt>pops(2));
%             total1 = max(1,total1);
%             total2 = max(1,total2);
%             total1 = round(numel(EA_1_Cnt)*tra);
%             total2 = round(numel(EA_2_Cnt)*tra);
            ind13 = ind12(1:total1);%根据次数排序
            ind14 = ind11(1:total1);%根据适应值排序
            ind1 = intersect(ind13,ind14);
            
            ind23 = ind22(1:total2);%根据次数排序
            ind24 = ind21(1:total2);%根据适应值排序
            ind2 = intersect(ind23,ind24);
            
            total1_indx = (1:total1);
            total2_indx = (1:total2);
            
            total1 = round(numel(ind1));
            total2 = round(numel(ind2));
            total = min(total1,total2);
            
            if total == 0
                EA_2(PS2,:)=EA_1(1,:);
                EA_obj2(PS2)=EA_obj1(1);
                EA_2_Cnt(PS2)=0;
                [EA_obj2, ind]=sort(EA_obj2);
                EA_2=EA_2(ind,:);
                Pre_EA_obj2=Pre_EA_obj2(ind,:);
                EA_2_Cnt=EA_2_Cnt(ind,:);
            else
    %             total = min(total,20);
    %             total = max(1,total);

    %            EA_obj2(ind2(ind22(total2_indx(1:total)),:));% 可以得到根据值排序的个体

                tmp = EA_2(ind2(total2_indx(1:total)),:);
                EA_2(ind2(total2_indx(1:total)),:)=EA_1(ind1(total1_indx(1:total)),:);
                EA_1(ind1(total1_indx(1:total)),:)=tmp;

                tmp2 = EA_obj2(ind2(total2_indx(1:total)),:);
                EA_obj2(ind2(total2_indx(1:total)),:)=EA_obj1(ind1(total1_indx(1:total)),:);
                EA_obj1(ind1(total1_indx(1:total)),:)=tmp2;

                tmp3 = EA_2_Cnt(ind2(total2_indx(1:total)),:);
                EA_2_Cnt(ind2(total2_indx(1:total)),:) = EA_1_Cnt(ind1(total1_indx(1:total)),:);
                EA_1_Cnt(ind1(total1_indx(1:total)),:) = tmp3;

                Pre_EA_obj2(ind2(total2_indx(1:total)),:) = Pre_EA_obj1(ind1(total1_indx(1:total)),:);

                [EA_obj2, ind]=sort(EA_obj2);
                EA_2=EA_2(ind,:);
                EA_2_Cnt = EA_2_Cnt(ind,:);
                Pre_EA_obj2=Pre_EA_obj2(ind,:);

                [EA_obj1, ind]=sort(EA_obj1);
                EA_1=EA_1(ind,:);
                EA_1_Cnt = EA_1_Cnt(ind,:);
            end
        else
            if (min (EA_2(1,:)))> -100 && (max(EA_2(1,:)))<100 %% share best sol. in EA_2 if it is feasible
%                 %%交换，将AGPSK中多次没有变化的个体使用IMODE算法
                [~, ind11]=sort(EA_obj1,'descend');
                [~, ind21]=sort(EA_obj2,'descend');

                [~,ind12] = sort(EA_1_Cnt,'descend');
                [~,ind22] = sort(EA_2_Cnt,'descend');

%                 total1 = round(numel(EA_obj1(:,1))*p);
%                 total2 = round(numel(EA_obj2(:,1))*p);
                total1 = sum(EA_1_Cnt>pops(1));
                total2 = sum(EA_2_Cnt>pops(2));
%                 total1 = max(1,total1);
%                 total2 = max(1,total2);
%                 total1 = round(numel(EA_1_Cnt)*tra);
%                 total2 = round(numel(EA_2_Cnt)*tra);

                ind13 = ind12(1:total1);%根据次数排序
                ind14 = ind11(1:total1);%根据适应值排序
                ind1 = intersect(ind13,ind14);

                ind23 = ind22(1:total2);%根据次数排序
                ind24 = ind21(1:total2);%根据适应值排序
                ind2 = intersect(ind23,ind24);
                
%                 total1_indx = randperm(total1);
%                 total2_indx = randperm(total2);
                total1_indx = (1:total1);
                total2_indx = (1:total2);
                
                total1 = round(numel(ind1));
                total2 = round(numel(ind2));
                total = min(total1,total2);
                if total == 0
                    EA_1(PS1,:)= EA_2(1,:);
                    EA_obj1(PS1)= EA_obj2(1);
                    EA_1_Cnt(PS1)=0;
                    [EA_obj1, ind]=sort(EA_obj1);
                    EA_1=EA_1(ind,:);
                    EA_1_Cnt=EA_1_Cnt(ind,:);
                else
        %             total = min(total,20);
    %                 total = max(1,total);

        %            EA_obj2(ind2(ind22(total2_indx(1:total)),:));% 可以得到根据值排序的个体

                    tmp = EA_2(ind2(total2_indx(1:total)),:);
                    EA_2(ind2(total2_indx(1:total)),:)=EA_1(ind1(total1_indx(1:total)),:);
                    EA_1(ind1(total1_indx(1:total)),:)=tmp;

                    tmp2 = EA_obj2(ind2(total2_indx(1:total)),:);
                    EA_obj2(ind2(total2_indx(1:total)),:)=EA_obj1(ind1(total1_indx(1:total)),:);
                    EA_obj1(ind1(total1_indx(1:total)),:)=tmp2;

                    tmp3 = EA_2_Cnt(ind2(total2_indx(1:total)),:);
                    EA_2_Cnt(ind2(total2_indx(1:total)),:) = EA_1_Cnt(ind1(total1_indx(1:total)),:);
                    EA_1_Cnt(ind1(total1_indx(1:total)),:) = tmp3;

                    Pre_EA_obj2(ind2(total2_indx(1:total)),:) = Pre_EA_obj1(ind1(total1_indx(1:total)),:);

        %             [EA_obj2, ind]=sort(EA_obj2);
        %             EA_2=EA_2(ind,:);
        %             EA_2_Cnt = EA_2_Cnt(ind,:);
        %             Pre_EA_obj2=Pre_EA_obj2(ind,:);

                    [EA_obj1, ind]=sort(EA_obj1);
                    EA_1=EA_1(ind,:);
                    EA_1_Cnt = EA_1_Cnt(ind,:);
                end
                
            end
            
        end
        %% reset cy and Probs
        cy=1;   Probs=ones(1,2);
        EA_2_Cnt=zeros(size(EA_2_Cnt));
        EA_1_Cnt=zeros(size(EA_1_Cnt));
        cur_best = min(min(EA_obj1),min(EA_obj2));
        if cur_best < pre_best
            pre_best = cur_best;
            no_change_times=0;
        else
            no_change_times = no_change_times + 1;
        end
        
    end

    if (rand<=Probs(1))

        %% apply IMODE
        [EA_1, EA_1old, EA_obj1,probDE1,bestold,bestx,archive,hist_pos,memory_size, archive_f,archive_Cr,archive_T,archive_freq, nfes,F,cr, res_det,EA_1_Cnt] = ...
            IMODE( EA_1,EA_1old, EA_obj1,probDE1,bestold,bestx,archive,hist_pos,memory_size, archive_f,archive_Cr,archive_T,....
            archive_freq, Par.xmin, Par.xmax,  Par.n,  PS1,  nfes, func_num,Par.Printing,Par.max_nfes, Par.Gmax,F,cr,C,fhd,res_det,EA_1_Cnt);
        if(~isempty(Par.Record_FEs))
            if (nfes>=Par.Record_FEs(1))
                Par.All_fit=[Par.All_fit;min(EA_obj1)];
                Par.Record_FEs(1)=[];
            end
        end
        if nfes >= max_nfes
            [Best_fit,I_best]= min(EA_obj1);
            X_best=EA_1(I_best,:);
            All_fit=Par.All_fit;
        end
        Pre_EA_obj1 = EA_obj1;

        plan_NP1 = round((((min_NP1 - max_NP1) / (max_nfes)) * nfes) + max_NP1);

        Par.p_best_rate = (((Par.p_best_rate_min - Par.p_best_rate_max) / (max_nfes)) * nfes) + Par.p_best_rate_max;
        
        if PS1 > plan_NP1
            reduction_ind_num = PS1 - plan_NP1;
            if PS1 - reduction_ind_num <  min_NP1
                reduction_ind_num = PS1 - min_NP1;
            end
            PS1 = PS1 - reduction_ind_num;
            for r = 1 : reduction_ind_num
                [valBest, indBest] = sort(EA_obj1, 'ascend');
                worst_ind = indBest(end);
                EA_1(worst_ind,:) = [];
                EA_obj1(worst_ind,:) = [];
                EA_1_Cnt(worst_ind,:) = [];
                Pre_EA_obj1(worst_ind,:) = [];
            end
            archive.NP = PS1;
            if size(archive.NP, 1) > archive.NP
                rndpos = randperm(size(archive.NP, 1));
                rndpos = rndpos(1 : archive.NP);
                archive.Pop = archive.Pop(rndpos, :);
            end
        end
        
    end
    
    if(rand<Probs(2))
        %% Apply APGSK
        [EA_2,EA_obj2,Par,nfes,res_det]= APGSK_fun(EA_2,EA_obj2,lu,func_num,Par,nfes,fhd,C,res_det);
        if(~isempty(Par.Record_FEs))
            if (nfes>=Par.Record_FEs(1))
                Par.All_fit=[Par.All_fit;min(EA_obj2)];
                Par.Record_FEs(1)=[];
            end
        end
        if nfes >= max_nfes
            [Best_fit,I_best]= min(EA_obj2);
            X_best=EA_2(I_best,:);
            All_fit=Par.All_fit;
%             return;
        end
        indx = (EA_obj2 < Pre_EA_obj2);
        Pre_EA_obj2 = EA_obj2;
        EA_2_Cnt(indx) = 0;
        indx2 = ~indx;
        EA_2_Cnt(indx2) = EA_2_Cnt(indx2)+1;
%          plan_NP2 = round(((min_NP - max_NP2)* ((nfes / max_nfes).^((1-nfes / max_nfes))))  + max_NP2);
        plan_NP2 = round(((((min_NP - max_NP2) / (max_nfes)) * nfes)) + max_NP2);
%         plan_NP2 = round(((min_NP - max_NP2)/max_nfes)*(nfes + PS2)*k_rate + max_NP2);
        Par.p_best_rate = (((Par.p_best_rate_min - Par.p_best_rate_max) / (max_nfes)) * nfes) + Par.p_best_rate_max;
        
        if PS2 > plan_NP2
            reduction_ind_num = PS2 - plan_NP2;
            if PS2 - reduction_ind_num <  min_NP
                reduction_ind_num = PS2 - min_NP;
            end
            PS2 = PS2 - reduction_ind_num;
            for r = 1 : reduction_ind_num
                [valBest, indBest] = sort(EA_obj2, 'ascend');
                worst_ind = indBest(end);
                EA_2(worst_ind,:) = [];
                EA_obj2(worst_ind,:) = [];
                Par.K(worst_ind,:)=[];
                Pre_EA_obj2(worst_ind)=[];
                EA_2_Cnt(worst_ind)=[];
            end
        end
    end
    
        Fit=[EA_obj1;EA_obj2];
        Pop=[EA_1;EA_2];
        [Best_fit,I_best]= min(Fit);
        X_best=Pop(I_best,:);
        All_fit=Par.All_fit;
        PopSize=size(Pop,1);
%         res_det= [res_det; repmat(Best_fit,PopSize,1)];
    
    if (nfes / max_nfes) >= (xxx / 10)
        if  xxx > 0
            filedata{xxx}=strcat(num2str(nfes),32, num2str(mean(Fit-Par.f_optimal)),32, num2str(min(Fit-Par.f_optimal)),'\n');
            %fprintf(fp,'%d %e %e\r\n', nfes, mean(Fit-Par.f_optimal), min(Fit-Par.f_optimal));
        end
        xxx=xxx+1;
    end
%         res_det= [res_det; repmat(Best_fit,PopSize,1)];
    if (nfes>=max_nfes && xxx==10)       
        filedata{xxx}=strcat(num2str(nfes),32, num2str(mean(Fit-Par.f_optimal)),32, num2str(min(Fit-Par.f_optimal)),'\n');
        %fprintf(fp,'%d %e %e\r\n', nfes, mean(Fit-Par.f_optimal), min(Fit-Par.f_optimal));
        xxx=11;
    end
%     disp(nfes);
    % fprintf('current_eval\t %d fitness\t %d \n', nfes, Best_fit);
    if (nfes>=max_nfes && xxx==11)
        stop_con=1;
    end
%     if ( (abs (Par.f_optimal - Best_fit)<= 1e-8))
%         stop_con=1;
%     end
end
for x=[1:11]
    if x==1
        fprintf(fp,filedata0);
    end
    if x~=1
        disp(filedata{x-1});
        fprintf(fp,filedata{x-1});
    end
end
end