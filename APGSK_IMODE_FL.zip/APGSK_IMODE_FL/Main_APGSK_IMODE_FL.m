clc
clear all
% mex cec21_func.cpp -DWINDOWS

format short e;
Runs=30;
fhd=@Parametrized_benchmark_func;
%NP = 100;
optimum= [300, 400,600,800,900,1800,2000,2200,2300,2400,2600,2700];
% optimum= [300, 400 ,600 ,800 ,900 ,1800 ,2000 ,2200 ,2300 ,2400 ,2600,2700];
% C is the Parametrized Selection Vector, where:
% C1 is Shift indicator (0=0 ,1=F*)
% C2 Translation indicator (0=0, 1=oi)
% C3 Rotation indicator (0=I 1=M)
R1 = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0;                1.98991800000000,3.97983600000000,1.98991800000000,3.97983600000000,1.98991800000000,3.97983600000000,2.98487700000000,3.97983600000000,2.98487700000000,3.97983600000000,3.97983600000000,4.97479500000000,3.97983600000000,4.97479500000000,3.97983600000000,3.97983600000000,4.97479500000000,0.994959100000000,5.96975400000000,3.97983600000000,1.98991800000000,3.97983600000000,1.98991800000000,2.98487700000000,3.97983600000000,3.97983600000000,4.97479500000000,2.98487700000000,1.98991800000000,1.98991800000000;0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0;0.0789890700000000,0.0347866400000000,0.0937041100000000,0.0253595300000000,0.0173659900000000,0.0122174600000000,0.0121408500000000,0.0310641700000000,0.0272146300000000,0.149391300000000,0.0419474600000000,0.200819300000000,0.0245545300000000,0.0727376400000000,0.0104526500000000,0.0122174600000000,0.0860790700000000,0.0160720900000000,0.0515740600000000,0.106581900000000,0.0173659900000000,0.0145885800000000,0.0787316800000000,0.0996682000000000,0.121075800000000,0.0145885800000000,0.258163100000000,0.0214770300000000,0.137328400000000,0.0173659900000000;0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0;0.00867686600000000,0.00372616300000000,0.000177810200000000,0.000290395500000000,0.00486972400000000,0.00891674300000000,0.000541809200000000,0.00193467800000000,0.00658491900000000,0.0207726200000000,8.75400000000000e-07,0.0264632300000000,8.75400000000000e-07,0.000151893600000000,0.000390487900000000,0.00891674300000000,0.00165451100000000,0.00592824000000000,0.0199784200000000,0.000365219300000000,0.00486972400000000,0.00193467800000000,0.00159711100000000,0.0158408600000000,0.0103428800000000,0.000782028100000000,0.00258993400000000,0.00566050300000000,0.000995225500000000,0.00486972400000000;229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,229.284400000000,0,229.284400000000,229.284400000000;51.3904700000000,100.204800000000,100.210300000000,100.226100000000,100.214100000000,100.197900000000,100.183200000000,100.208700000000,100.169700000000,100.208400000000,100.179500000000,100.192800000000,100.179500000000,100.187000000000,100.240500000000,100.197900000000,100.220200000000,100.191400000000,100.196400000000,100.208200000000,100.214100000000,100.195500000000,100.205300000000,100.191900000000,100.212600000000,47.9093800000000,100.174400000000,100.208800000000,33.8807800000000,100.154700000000;0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0;159.368700000000,158.618400000000,159.368700000000,159.368700000000,159.368700000000,159.368700000000,159.368700000000,158.618400000000,159.368700000000,158.618400000000,162.183400000000,159.368700000000,159.368700000000,158.618400000000,158.618400000000,159.368700000000,161.290600000000,159.368700000000,159.368700000000,159.368700000000,159.368700000000,158.618400000000,158.618400000000,159.368700000000,158.618400000000,158.618400000000,158.618400000000,159.368700000000,159.368700000000,159.368700000000];
Selection_Vector = [
    %     0 0 0;
    %     0 0 1;
    %     0 1 0;
    %     0 1 1;
    %     1 0 0;
    %     1 0 1;
    %     1 1 0;
    1 1 1
    ]; %% Change to select the benchmark

lb = -100;
ub = 100;
% load Rand_Seeds Rand_Seeds
myCluster = parcluster('local');
myCluster.NumWorkers = 10;  % define how many processors to use
R2 = zeros(12,30);
for D = [10]
    %Final_results=zeros(10,5);    %% to save the final results
    if D == 5
        filename2 = strcat(strcat('results_\results','_APGSK_IMODE_FL_5_2022.txt'));
    elseif D == 10
        filename2 = strcat(strcat('results_\results','_APGSK_IMODE_FL_10_2022.txt'));
    elseif D == 15
        filename2 = strcat(strcat('results_\results','_APGSK_IMODE_FL_15_2022.txt'));
    elseif D == 20
        filename2 = strcat(strcat('results_\results','_APGSK_IMODE_FL_20_2022.txt'));
    end
    fp2 = fopen(filename2,'a+');
    
    Final_results=zeros(12,5);    %% to save the final results
    
    switch D
        
        case 10
            max_nfes=1000000;
        case 20
            max_nfes=10000000;
        otherwise
            disp('Error..')
    end
    
    
    for i=1:size(Selection_Vector,1)
        res=[];
        C=Selection_Vector(i,:);
        for func_num=[4 6 8 9 10 12]
            Par= Introd_Par(func_num,D, C); %% set of parameters
            
            Alg_Name=[ 'APGSK_IMODE_FL_D' num2str(D) '_(' num2str(C(1)) num2str(C(2)) num2str(C(3)) ')'];
            funcval_out=zeros(Runs,1);
            fprintf('\n-------------------------------------------------------\n')
            fprintf('Running %s on Function = %d, Dimension size = %d\n',Alg_Name, func_num, D)
            vv=[];
            parfor Run_No=1:Runs
%             for Run_No=1:Runs 
                [Best_solution, BestFit, Conv_Fit,nfes,res] = APGSK_IMODE_FL(max_nfes,lb,ub,func_num,D,fhd,C,Par,Run_No);
                
                if(C(1)==1)
                    BestFit=BestFit-optimum(func_num);
                    Conv_Fit=Conv_Fit-optimum;
                end           
                funcval_out(Run_No) = BestFit;
                fprintf('run:%d \t\t BestFit: %e \t\t nfes: %d\n',Run_No ,BestFit,nfes);
                %             file_name=sprintf('Figures\\%s_CEC2017_Problem#%s_problemSize#%s_Run#%s',Alg_Name,int2str(func_num),int2str(Run_No),int2str(D));
                %             save(file_name,'Conv_Fit');
                
                if Par.Printing==1
                    res= res- repmat(Par.f_optimal,size(res,2),1);
                    res(res<=1e-08)=0;
                    ss=size(res,1);
                    endv=res(ss);
                    if size(res,2)<Par.max_nfes
                        res(size(res,1):Par.max_nfes)=endv;
                    end
                    ress=res';
                    vv(Run_No,:)= ress(1:Par.max_nfes);
                end
                ress=[];
            end
            if func_num==4
                R4 = [1.989918e+00 3.979836e+00 1.989918e+00 3.979836e+00 1.989918e+00 3.979836e+00 2.984877e+00 3.979836e+00 2.984877e+00 3.979836e+00 3.979836e+00 4.974795e+00 3.979836e+00 4.974795e+00 3.979836e+00 3.979836e+00 4.974795e+00 9.949591e-01 5.969754e+00 3.979836e+00 1.989918e+00 3.979836e+00 1.989918e+00 2.984877e+00 3.979836e+00 3.979836e+00 4.974795e+00 2.984877e+00 1.989918e+00 1.989918e+00 ];
                [p, q] = ranksum(R4,funcval_out);
                if q==1 && mean(R4)<mean(funcval_out)
                    disp("f4输");
                    break;
                end
            end
            %% to print the convergence of ech run % set 0 if not
            
            %             fprintf('min error value = %1.3e, max = %1.3e, median = %1.3e, mean = %1.3e, std = %1.3e\n', min(funcval_out), max(funcval_out), median(funcval_out), mean(funcval_out), std(funcval_out))
            Final_results(func_num,:)= [min(funcval_out),max(funcval_out),median(funcval_out), mean(funcval_out),std(funcval_out)];
            R2(func_num,:) = funcval_out;
            disp(Final_results);
            file_name=sprintf('Results\\f#%s_CEC2021_%s',int2str(func_num),Alg_Name);
            save(file_name,'funcval_out');
            filename = strcat(strcat('Fx_\F',num2str(func_num)),'_APGSK_IMODE_FL_',num2str(D),'_2022_long.txt');
            fp = fopen(filename,'a+');
            fprintf(fp,'%.2e (%.2e): \r\n', mean(funcval_out), std(funcval_out)); 
            
            
            fprintf(fp2,'F%d: %.2e  (%.2e): ',func_num , mean(funcval_out), std(funcval_out));

            for x = 1 : 30  
                fprintf(fp,'%e ', funcval_out(x)); 
                fprintf(fp2,'%s ', num2str(funcval_out(x)));
            end
            fprintf(fp2,'\n');
            %% save the results in a text
            save('results.txt', 'Final_results', '-ascii');
            %% fitness values at different levels of the optimization process
            %%% required by the competition
            if Par.Printing==1
                for k=1:16
                    lim(k)=Par.n^(((k-1)/5)-3).*Par.max_nfes;
                end
                lim= ceil(lim);
                %         lim= [0.01, 0.02, 0.03, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0].*Par.Max_FES;
                res_to_print= vv(:,lim);
                name1 = 'Results_Record\APGSK_IMODE_FL_';
                name2 = num2str(func_num);
                name3 = '_';
                name4 = [num2str(C(1)) num2str(C(2)) num2str(C(3))];
                name5 = '_';
                name6= num2str(Par.n);
                name7= '.txt';
                f_name=strcat(name1,name2,name3,name4,name5,name6,name7);
                res_to_print=res_to_print';
                save(f_name, 'res_to_print', '-ascii');
                name1 = 'Results_Record\seeds_';
                f_name=strcat(name1,name2,name3,name4,name5,name6,name7);
                %% save the seeds used - if needed
                %         myMatrix2= double(seed_run);
                %         save(f_name, 'myMatrix2', '-ascii');
                
            end
        end
    end
    
end
cal_result(R2)