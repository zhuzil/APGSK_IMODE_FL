
clc
clear all
% mex cec21_func.cpp -DWINDOWS

format short e;
Runs=30;
fhd=@Parametrized_benchmark_func;
%NP = 100;
optimum= [300, 400 ,600 ,800 ,900 ,1800 ,2000 ,2200 ,2300 ,2400 ,2600,2700];

% C is the Parametrized Selection Vector, where:
% C1 is Shift indicator (0=0 ,1=F*)
% C2 Translation indicator (0=0, 1=oi)
% C3 Rotation indicator (0=I 1=M)

Selection_Vector = [
    %     0 0 0;
    %     0 0 1;
    %     0 1 0;
    %     0 1 1;
    %     1 0 0;
    %     1 0 1;
    %     1 1 0;
    1 1 1
    ]; %% Change to select the benchmark

lb = -100;
ub = 100;
% load Rand_Seeds Rand_Seeds
myCluster = parcluster('local');
myCluster.NumWorkers = 1;  % define how many processors to use
for D = [10]
    Final_results=zeros(10,5);    %% to save the final results
    
    switch D
        case 10
            max_nfes=1000000;
        case 20
            max_nfes=10000000;
        otherwise
            disp('Error..')
    end
    
    for i=1:size(Selection_Vector,1)
        res=[];
        C=Selection_Vector(i,:);
        for func_num=[4:12]
            Par= Introd_Par(func_num,D, C); %% set of parameters
            
            Alg_Name=[ 'APGSK_IMODE_D' num2str(D) '_(' num2str(C(1)) num2str(C(2)) num2str(C(3)) ')'];
            funcval_out=zeros(Runs,1);
            fprintf('\n-------------------------------------------------------\n')
            fprintf('Running %s on Function = %d, Dimension size = %d\n',Alg_Name, func_num, D)
            vv=[];
  
            parfor Run_No=1:Runs
                [Best_solution, BestFit, Conv_Fit,nfes,res] = APGSK_IMODE(max_nfes,lb,ub,func_num,D,fhd,C,Par,Run_No);
                
                if(C(1)==1)
                    BestFit=BestFit-optimum(func_num);
                    Conv_Fit=Conv_Fit-optimum;
                end
%                 
%                 if(BestFit<1e-8)
%                     BestFit=0;
%                 end
                funcval_out(Run_No) = BestFit;
                fprintf('run:%d \t\t BestFit: %e \t\t nfes: %d\n',Run_No ,BestFit,nfes);
                %             file_name=sprintf('Figures\\%s_CEC2017_Problem#%s_problemSize#%s_Run#%s',Alg_Name,int2str(func_num),int2str(Run_No),int2str(D));
                %             save(file_name,'Conv_Fit');
                if Par.Printing==1
                    res= res- repmat(Par.f_optimal,size(res,2),1);
                    res(res<=1e-08)=0;
                    ss=size(res,1);
                    endv=res(ss);
                    if size(res,2)<Par.max_nfes
                        res(size(res,1):Par.max_nfes)=endv;
                    end
                    ress=res';
                    vv(Run_No,:)= ress(1:Par.max_nfes);
                end
                ress=[];
            end
            
            %% to print the convergence of ech run % set 0 if not
            
            %             fprintf('min error value = %1.3e, max = %1.3e, median = %1.3e, mean = %1.3e, std = %1.3e\n', min(funcval_out), max(funcval_out), median(funcval_out), mean(funcval_out), std(funcval_out))
            Final_results(func_num,:)= [min(funcval_out),max(funcval_out),median(funcval_out), mean(funcval_out),std(funcval_out)];
            
%             if D==10
%                 filename2=strcat('results_\22_results_APGSK_IMODE_10_2022_long.txt');
%             else
%                 filename2 = strcat('results_\22_results_APGSK_IMODE_20_2022_long.txt');
%             end
            filename2 = strcat(strcat('results_\results','_APGSK_IMODE_',num2str(D),'_2022_long.txt'));
            fp2 = fopen(filename2,'a+');            
            filename = strcat(strcat('Fx_\F',num2str(func_num)),'_APGSK_IMODE_',num2str(D),'_2022_long.txt');
            fp = fopen(filename,'a+');
            
            fprintf(fp,'%.2e (%.2e): \r\n', mean(funcval_out), std(funcval_out)); 
            fprintf(fp2,'F%d: %.2e  (%.2e): ',func_num , mean(funcval_out), std(funcval_out));
            for x = 1 : Runs
                fprintf(fp,'%e ', funcval_out(x));   
                fprintf(fp2,'%e ', funcval_out(x));
            end
            fprintf(fp2,'\n');
            

%             
%             disp(Final_results);
%             file_name=sprintf('Results\\f#%s_CEC2021_%s',int2str(func_num),Alg_Name);
%             save(file_name,'funcval_out');
            
            %% save the results in a text
            save('results.txt', 'Final_results', '-ascii');
            
            %% fitness values at different levels of the optimization process
            %%% required by the competition
            if Par.Printing==1
                for k=1:16
                    lim(k)=Par.n^(((k-1)/5)-3).*Par.max_nfes;
                end
                lim= ceil(lim);
                %         lim= [0.01, 0.02, 0.03, 0.05, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0].*Par.Max_FES;
                res_to_print= vv(:,lim);
                name1 = 'Results_Record\APGSK_IMODE_';
                name2 = num2str(func_num);
                name3 = '_';
                name4 = [num2str(C(1)) num2str(C(2)) num2str(C(3))];
                name5 = '_';
                name6= num2str(Par.n);
                name7= '.txt';
                f_name=strcat(name1,name2,name3,name4,name5,name6,name7);
                res_to_print=res_to_print';
                save(f_name, 'res_to_print', '-ascii');
                name1 = 'Results_Record\seeds_';
                f_name=strcat(name1,name2,name3,name4,name5,name6,name7);
                %% save the seeds used - if needed
                %         myMatrix2= double(seed_run);
                %         save(f_name, 'myMatrix2', '-ascii');
                
            end
        end
    end
    
end
