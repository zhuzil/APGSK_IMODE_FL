function [pop,fitness,Par,nfes,res_det]= APGSK_fun(pop,fitness,lu,func,Par,nfes,fhd,C,res_det)

[pop_size,problem_size]=size(pop);

KF_pool = [0.1 1.0 0.5 1.0];
KF_poool= [-0.1 -0.1 -0.1 -0.1];
KR_pool = [0.2 0.1 0.9 0.9];

max_nfes=Par.max_nfes;
All_Imp=Par.All_Imp;
KW_ind=Par.KW_ind;



if  (nfes < 0.1*max_nfes)% intial probability values
    KW_ind=[0.85 0.05 0.05 0.05];
    K_rand_ind=rand(pop_size, 1);
    K_rand_ind(K_rand_ind>sum(KW_ind(1:3))&K_rand_ind<=sum(KW_ind(1:4)))=4;
    K_rand_ind(K_rand_ind>sum(KW_ind(1:2))&K_rand_ind<=sum(KW_ind(1:3)))=3;
    K_rand_ind(K_rand_ind>KW_ind(1)&K_rand_ind<=sum(KW_ind(1:2)))=2;
    K_rand_ind(K_rand_ind>0&K_rand_ind<=KW_ind(1))=1;
    KF=KF_pool(K_rand_ind)';
    KR=KR_pool(K_rand_ind)';
else %% updaing probability values
    KW_ind=0.95*KW_ind+0.05*All_Imp;
    KW_ind=KW_ind./sum(KW_ind);
    K_rand_ind=rand(pop_size, 1);
    K_rand_ind(K_rand_ind>sum(KW_ind(1:3))&K_rand_ind<=sum(KW_ind(1:4)))=4;
    K_rand_ind(K_rand_ind>sum(KW_ind(1:2))&K_rand_ind<=sum(KW_ind(1:3)))=3;
    K_rand_ind(K_rand_ind>KW_ind(1)&K_rand_ind<=sum(KW_ind(1:2)))=2;
    K_rand_ind(K_rand_ind>0&K_rand_ind<=KW_ind(1))=1;
    % KF=KF_pool(K_rand_ind)';
    KR=KR_pool(K_rand_ind)';
    if rand>=0.1 && nfes>0.5*max_nfes
        KF=KF_pool(K_rand_ind)';
    else
        KF=KF_poool(K_rand_ind)';
    end
    
end

%%% Junior and Senior Gaining-Sharing phases %%%%%
%D_Gained_Shared_Junior=ceil((problem_size)*(1-nfes / max_nfes).^K);
if rand >(nfes / max_nfes)
    D_Gained_Shared_Junior=ceil((1)* round((problem_size)* ((1-nfes / max_nfes).^((0.5)))));
    
else
    D_Gained_Shared_Junior=ceil((1)* round((problem_size)* ((1-nfes / max_nfes).^((2)))));
end

D_Gained_Shared_Senior=problem_size-D_Gained_Shared_Junior;

[valBest, indBest] = sort(fitness, 'ascend');
[Rg1, Rg2, Rg3] = Gained_Shared_Junior_R1R2R3(indBest);

[R1, R2, R3] = Gained_Shared_Senior_R1R2R3(indBest);
R01=1:pop_size;
Gained_Shared_Junior=zeros(pop_size, problem_size);
ind1=fitness(R01)>fitness(Rg3);

if(sum(ind1)>0)
    Gained_Shared_Junior (ind1,:)= pop(ind1,:) + KF(ind1, ones(1,problem_size)).* (pop(Rg1(ind1),:) - pop(Rg2(ind1),:)+pop(Rg3(ind1), :)-pop(ind1,:)) ;
end
ind1=~ind1;
if(sum(ind1)>0)
    Gained_Shared_Junior(ind1,:) = pop(ind1,:) + KF(ind1, ones(1,problem_size)) .* (pop(Rg1(ind1),:) - pop(Rg2(ind1),:)+pop(ind1,:)-pop(Rg3(ind1), :)) ;
end
R0=1:pop_size;
Gained_Shared_Senior=zeros(pop_size, problem_size);
ind=fitness(R0)>fitness(R2);
if(sum(ind)>0)
    Gained_Shared_Senior(ind,:) = pop(ind,:) + KF(ind, ones(1,problem_size)) .* (pop(R1(ind),:) - pop(ind,:) + pop(R2(ind),:) - pop(R3(ind), :)) ;
end
ind=~ind;
if(sum(ind)>0)
    Gained_Shared_Senior(ind,:) = pop(ind,:) + KF(ind, ones(1,problem_size)) .* (pop(R1(ind),:) - pop(R2(ind),:) + pop(ind,:) - pop(R3(ind), :)) ;
end
Gained_Shared_Junior = boundConstraint(Gained_Shared_Junior, pop, lu);
Gained_Shared_Senior = boundConstraint(Gained_Shared_Senior, pop, lu);


D_Gained_Shared_Junior_mask=rand(pop_size, problem_size)<=(D_Gained_Shared_Junior(:, ones(1, problem_size))./problem_size); % mask is used to indicate which elements of will be gained
D_Gained_Shared_Senior_mask=~D_Gained_Shared_Junior_mask;

D_Gained_Shared_Junior_rand_mask=rand(pop_size, problem_size)<=KR(:,ones(1, problem_size));
D_Gained_Shared_Junior_mask=and(D_Gained_Shared_Junior_mask,D_Gained_Shared_Junior_rand_mask);

D_Gained_Shared_Senior_rand_mask=rand(pop_size, problem_size)<=KR(:,ones(1, problem_size));
D_Gained_Shared_Senior_mask=and(D_Gained_Shared_Senior_mask,D_Gained_Shared_Senior_rand_mask);
ui=pop;

ui(D_Gained_Shared_Junior_mask) = Gained_Shared_Junior(D_Gained_Shared_Junior_mask);
ui(D_Gained_Shared_Senior_mask) = Gained_Shared_Senior(D_Gained_Shared_Senior_mask);

children_fitness = feval(fhd, ui', func,C);
children_fitness = children_fitness';
for i = 1 : pop_size
    nfes = nfes + 1;
    if nfes > max_nfes
        break;
    end
    if children_fitness(i) < valBest(1)
        valBest(1) = children_fitness(i);
        bsf_solution = ui(i, :);
    end
    
end

%%%%  Calculate the improvemnt of each settings %%%
dif = abs(fitness - children_fitness);
%% I == 1: the parent is better; I == 2: the offspring is better
Child_is_better_index = (fitness > children_fitness);
dif_val = dif(Child_is_better_index == 1);
All_Imp=zeros(1,4);% (1,4) delete for 4 cases
for i=1:4
    if(sum(and(Child_is_better_index,K_rand_ind==i))>0)
        All_Imp(i)=sum(dif(and(Child_is_better_index,K_rand_ind==i)));
    else
        All_Imp(i)=0;
    end
end

if(sum(All_Imp)~=0)
    All_Imp=All_Imp./sum(All_Imp);
    [temp_imp,Imp_Ind] = sort(All_Imp);
    for imp_i=1:length(All_Imp)-1
        All_Imp(Imp_Ind(imp_i))=max(All_Imp(Imp_Ind(imp_i)),0.05);
    end
    All_Imp(Imp_Ind(end))=1-sum(All_Imp(Imp_Ind(1:end-1)));
else
    Imp_Ind=1:length(All_Imp);
    All_Imp(:)=1/length(All_Imp);
end
[fitness, Child_is_better_index] = min([fitness, children_fitness], [], 2);

pop(Child_is_better_index == 2, :) = ui(Child_is_better_index == 2, :);



Par.All_Imp=All_Imp;
Par.KW_ind=KW_ind;

bestold=min(fitness);
if bestold<res_det(end)
res_det= [res_det ;repmat(bestold,pop_size,1)];
else
    res_det= [res_det ;repmat(res_det(end),pop_size,1)];
end
end