function write_files(C,D)
% write_files writes Shift, Rotation Matrix files from CEC2021_input_data
% foldser or Parametrized_input_data folder accordeing to the problem size (D) and Selection Vector C where: 
% C1 is Shift indicator (0=0 ,1=F*)
% C2 Translation indicator (0=0, 1=oi)
% C3 Rotation indicator (0=I 1=M)
% Call:
%    write_files(C,D)
%
% Version: 0.1  Date: 2021/11/17
% Written by Anas A. Hadi (anas1401@gmail.com)


CEC2020_Func_num =[1,2,3,7,4,16,6,22,24,25];


for func_num=CEC2020_Func_num
    %% Copy shift data (Translation)
    fname=['shift_data_' num2str(func_num) '.txt'];
    if(C(2)==0)
        status = copyfile(['Parametrized_input_data\' fname],['input_data\' fname], 'f');
        if(status==0)
            error(['Error in copying file:' fname])
        end
    else
        status = copyfile(['CEC2021_input_data\' fname],['input_data\' fname], 'f');
        if(status==0)
            error(['Error in copying file:' fname])
        end
    end
    
    
    %% Copy Rotation Matrix (Translation)
    M_fname=['M_' num2str(func_num) '_D' num2str(D) '.txt'];
    shuffle_fname=['shuffle_data_' num2str(func_num) '_D' num2str(D) '.txt'];
    if(C(3)==0)
        status = copyfile(['Parametrized_input_data\' M_fname],['input_data\' M_fname], 'f');
        if(status==0)
            error(['Error in copying file:' M_fname])
        end
        status = copyfile(['Parametrized_input_data\' shuffle_fname],['input_data\' shuffle_fname], 'f');
        if(status==0)
            error(['Error in copying file:' shuffle_fname])
        end
    else
        status = copyfile(['CEC2021_input_data\' M_fname],['input_data\' M_fname], 'f');
        if(status==0)
            error(['Error in copying file:' M_fname])
        end
        status = copyfile(['CEC2021_input_data\' shuffle_fname],['input_data\' shuffle_fname], 'f');
        if(status==0)
            error(['Error in copying file:' shuffle_fname])
        end
    end
    
    
end


end

